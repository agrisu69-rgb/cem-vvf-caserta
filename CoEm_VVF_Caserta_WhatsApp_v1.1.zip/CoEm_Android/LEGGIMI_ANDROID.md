# Co.Em. VVF Caserta – progetto Android nativo

Progetto Android (Gradle + Java, Capacitor) con condivisione delle segnalazioni e delle fotografie tramite WhatsApp. Per compilare l'APK servono Node.js, Android Studio/Gradle e una connessione Internet al primo avvio.

## Dati dell'app
- Nome: Co.Em. VVF Caserta
- Identificativo (applicationId): `it.coem.vvfcaserta` (cambiarlo prima della prima pubblicazione, se il Comando ne vuole uno suo)
- Versione: 1.1 · Android minimo: 7.0 (API 24) · target: API 36

## File principali
| File | A cosa serve |
|---|---|
| `android/app/src/main/java/it/coem/vvfcaserta/MainActivity.java` | Avvio dell'app (Activity nativa) |
| `android/app/src/main/AndroidManifest.xml` | Nome, icona, permessi |
| `android/app/build.gradle` | Identificativo, versione, firma |
| `android/app/src/main/res/` | Icone e schermata d'avvio in tutte le risoluzioni |
| `android/app/src/main/assets/public/` | L'app vera e propria (schermate e funzioni) |
| `node_modules/@capacitor/android/` | Libreria nativa Capacitor; le dipendenze vengono ripristinate con `npm ci` |
| `www/` + `capacitor.config.json` | Sorgente dell'app, da usare con `npx cap sync android` dopo una modifica |

## Strada 1 – Android Studio (dal PC)
1. Installa Node.js 22 e Android Studio (developer.android.com/studio), quindi scompatta questo ZIP.
2. Dalla cartella principale del progetto esegui `npm ci` e poi `npx cap sync android` (serve una connessione Internet la prima volta).
3. In Android Studio scegli **File → Open** e apri la cartella `android`.
4. Attendi la fine di "Gradle sync" (la prima volta scarica gli strumenti, qualche minuto).
5. APK di prova: **Build → Build App Bundle(s) / APK(s) → Build APK(s)**. Il file è in
   `android/app/build/outputs/apk/debug/app-debug.apk`.
6. Per il Play Store: **Build → Generate Signed App Bundle / APK → Android App Bundle**,
   crea una chiave (file .jks) e conservala con la password: senza, niente aggiornamenti.

## Strada 2 – GitHub, senza PC
1. Carica tutto il contenuto di questa cartella in un repository GitHub (la cartella `.github` compresa).
2. Il workflow installa Node.js, le dipendenze e sincronizza Capacitor prima di compilare.
3. Ad ogni caricamento parte "Crea APK" (scheda **Actions**); dopo qualche minuto l'APK è in **Releases**,
   con un link scaricabile da mandare su WhatsApp.

## Installare l'APK sul telefono
Apri il file → consenti **Installa app sconosciute** per l'app da cui lo apri (WhatsApp, File) → **Installa**.

## Condivisione CO.EM. tramite WhatsApp (senza server)
- Dopo aver preparato una segnalazione, l'app apre una conferma e può condividere il riepilogo e le fotografie con WhatsApp.
- L'operatore deve scegliere manualmente il gruppo CO.EM. e premere **Invia** in WhatsApp. L'app non può selezionare da sola il gruppo né verificare che il messaggio sia stato spedito.
- La condivisione allega le fotografie; i video non vengono allegati da questa funzione.
- Prima dell'invio verificare sempre che le immagini siano autorizzate e non mostrino dati personali o elementi non divulgabili.

## Da sapere
- Questa versione conserva gli archivi sul singolo telefono. Senza un server o un archivio condiviso, segnalazioni, utenti, turni, chat e aggiornamenti non si sincronizzano tra telefoni: WhatsApp trasmette solo il messaggio e gli allegati scelti.
- La compilazione dell'APK richiede Android Studio/Gradle o il workflow GitHub; il primo avvio di Gradle deve poter scaricare gli strumenti necessari.
- Nell'app installata i pulsanti di download (PDF, CSV, ZIP) richiedono il plugin `@capacitor/filesystem`: da aggiungere separatamente.
