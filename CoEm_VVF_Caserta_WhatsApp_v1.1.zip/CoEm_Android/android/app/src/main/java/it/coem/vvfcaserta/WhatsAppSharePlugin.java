package it.coem.vvfcaserta;

import android.content.ClipData;
import android.content.Intent;
import android.net.Uri;
import android.util.Base64;

import androidx.core.content.FileProvider;

import com.getcapacitor.JSArray;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.util.ArrayList;

@CapacitorPlugin(name = "WhatsAppShare")
public class WhatsAppSharePlugin extends Plugin {
    @PluginMethod
    public void share(PluginCall call) {
        try {
            String text = call.getString("text", "");
            JSArray files = call.getArray("files", new JSArray());
            ArrayList<Uri> uris = new ArrayList<>();
            File dir = new File(getContext().getCacheDir(), "coem-share");
            if (!dir.exists() && !dir.mkdirs()) {
                call.reject("Impossibile preparare le fotografie.");
                return;
            }

            for (int i = 0; i < files.length(); i++) {
                JSONObject item = files.getJSONObject(i);
                if (item == null) continue;
                String name = item.optString("name", "foto_" + (i + 1) + ".jpg");
                String data = item.optString("data", "");
                if (data.isEmpty()) continue;
                name = name.replaceAll("[^A-Za-z0-9._-]", "_");
                if (!name.toLowerCase().endsWith(".jpg") && !name.toLowerCase().endsWith(".jpeg") && !name.toLowerCase().endsWith(".png")) {
                    name += ".jpg";
                }
                byte[] bytes = Base64.decode(data, Base64.DEFAULT);
                File out = new File(dir, System.currentTimeMillis() + "_" + i + "_" + name);
                try (FileOutputStream stream = new FileOutputStream(out)) {
                    stream.write(bytes);
                }
                Uri uri = FileProvider.getUriForFile(getContext(), getContext().getPackageName() + ".fileprovider", out);
                uris.add(uri);
            }

            Intent send;
            if (uris.size() > 1) {
                send = new Intent(Intent.ACTION_SEND_MULTIPLE);
                send.setType("image/*");
                send.putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris);
                if (!text.isEmpty()) send.putExtra(Intent.EXTRA_TEXT, text);
                send.setClipData(ClipData.newUri(getContext().getContentResolver(), "Fotografie intervento", uris.get(0)));
                for (int i = 1; i < uris.size(); i++) {
                    send.getClipData().addItem(new ClipData.Item(uris.get(i)));
                }
            } else if (uris.size() == 1) {
                send = new Intent(Intent.ACTION_SEND);
                send.setType("image/jpeg");
                send.putExtra(Intent.EXTRA_STREAM, uris.get(0));
                if (!text.isEmpty()) send.putExtra(Intent.EXTRA_TEXT, text);
                send.setClipData(ClipData.newUri(getContext().getContentResolver(), "Fotografia intervento", uris.get(0)));
            } else {
                send = new Intent(Intent.ACTION_SEND);
                send.setType("text/plain");
                send.putExtra(Intent.EXTRA_TEXT, text);
            }

            send.setPackage("com.whatsapp");
            send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            Intent chooser = Intent.createChooser(send, "Scegli il gruppo WhatsApp CO.EM.");
            chooser.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            getActivity().startActivity(chooser);

            JSObject result = new JSObject();
            result.put("opened", true);
            result.put("photos", uris.size());
            call.resolve(result);
        } catch (Exception e) {
            call.reject("Impossibile aprire WhatsApp. Verifica che sia installato e riprova.", e);
        }
    }
}
